import random 
from micrograd.engine import Value

a=Value(6)
b=Value(7)
print(a+b)
